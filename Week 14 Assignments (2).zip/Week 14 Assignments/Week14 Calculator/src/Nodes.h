#ifndef __NODE_H__
#define __NODE_H__

struct Node
{
    void *data;
    struct Node *next;
};

#endif