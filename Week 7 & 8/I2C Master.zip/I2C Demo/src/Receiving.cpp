#ifndef RECEIVING
#define RECEIVING

#include <Wire.h>

void GetData()
{
    // if (Wire.available() > 0)
    // {
    //     uint8_t receivedByte = Wire.read();
    // }
}

#endif