#include <Arduino.h>
#include <Wire.h>
#include <string.h>

#define DeviceAddress 42
#define Timer 12000

uint32_t LastTime = 0;
bool isReloading = false;
uint8_t AnimationCounter = 0;
uint32_t AnimationTime = 0;

const char EndChar = '#';
const char Indexer = ':';
const int RegisterAddresses[4] = {21, 22, 23, 24};

typedef enum Program_State
{
  SERIAL_INPUT,
  DATA_PROCESSING,
  I2C_COM,
  IDLE,
  SERIAL_OUTPUT
} Program_State;

Program_State ProgramState = SERIAL_INPUT;

void ProgramProceed();
void printOutput();
void Reloading();

typedef enum Commands
{
  SET_A,
  SET_B,
  MIN,
  MAX,
  NA_Command
} Commands;

//--------------- SERIAL COM ---------------//

char SerialInput = 0;
char SerialBuffer[20];
uint8_t counter = 0;

//Receiveing Data Funcs
void getInput();
void filterInput();
//Processing Data Funcs
bool ProcessData();
int getIndexOf(char);
Commands extractComand(int, int);
int extractData(uint8_t);
int powerOf(int base, int power);
bool CompareStrings(char *String1, const char String2[], int SizeOfString1);

//---------------- I2C COM ----------------//

typedef enum COMBUS_State
{
  SENDING,
  RECEIVING,
  SUCCESS_CHECK
} COMBUS_State;

COMBUS_State I2C_ComBus_State = SENDING;

Commands CommandToBeSend;
int DataToBeSend;
int CheckupData;

void I2C_COM_Sequence();
void TransmitMsg();
bool ReceiveMsg();

//----------- setup -----------//
void setup()
{
  //Seting up LED pin
  // DDRD |= (1 << LED_PIN);
  // PIND &= ~(1 << LED_PIN);

  Serial.begin(9600);
  Wire.begin();

  Serial.print("\nHello There!\nPlease Input a command!\nYou can Set Registers and Read the Max and Min value of those registers!\nCommand Set:\n 1 - SET_A:<Value>\n 2 - SET_B:<Value>\n 3 - MIN:\n 4 - MAX:\n\n");
  Serial.print("> ");
}

//------------ loop ------------//
void loop()
{
  //Serial.println(ProgramState);
  switch (ProgramState)
  {
  case SERIAL_INPUT:
    //Serial.print("Please input a string!");
    getInput();
    break;

  case DATA_PROCESSING:
    // if input is correct program proceds else request input
    if (ProcessData())
      ProgramProceed();
    else
    {
      Serial.print("-->>>--\nERROR: Such a command does not exist!\n--<<<--");
      Serial.print("\n> ");
      ProgramState = SERIAL_INPUT;
    }
    break;

  case I2C_COM:
    I2C_COM_Sequence();
    break;

  case SERIAL_OUTPUT:
    printOutput();
    break;

  case IDLE:
    static bool isPrinted = false;
    if (isPrinted == false)
    {
      Serial.print("-> Loading");
      isPrinted = true;
    }

    if (millis() - LastTime > Timer)
    {
      AnimationCounter = 0;
      AnimationTime = 0;
      isReloading = false;
      isPrinted = false;
      ProgramProceed();
      LastTime = millis();
      //Serial.print("\n> ");
    }

    if (isReloading)
      Reloading();
    else
      isReloading = true;

    break;
  }
}

//---------- General function ------------//
//func used to control the flow of the program
void ProgramProceed()
{
  (ProgramState != SERIAL_OUTPUT) ? ProgramState = (Program_State)((int)ProgramState + 1) : ProgramState = SERIAL_INPUT;
}

//------------ Serial_Input -------------//
// receives the serial input from the terminal
void getInput()
{
  //get data
  if (Serial.available() > 0)
  {
    Serial.readBytes(&SerialInput, 1);
  }
  filterInput();
}
// filters the Serial input from the teminal
void filterInput()
{
  //filter the noise
  if (SerialInput != 0)
  {
    //cher the value
    switch (SerialInput)
    {
    case '\n':
      if (counter <= 1)
      {
        Serial.print("\n> ");
      }
      else
      {
        Serial.print("\n");
        SerialBuffer[counter - 1] = EndChar;

        ProgramProceed();
      }
      counter = 0;
      break;

    case (char)0x08:
      if (counter == 0)
        break;
      Serial.print(SerialInput);
      Serial.print((char)0x20);
      Serial.print(SerialInput);
      counter--;
      break;

    default:
      if (counter < 20)
      {
        Serial.print(SerialInput);
        SerialBuffer[counter] = SerialInput;
        counter++;
      }
      break;
    }
  }
  SerialInput = 0;
}

//-------------Process_Data -------------//
//proceses and cheks for valid data
bool ProcessData()
{
  int IndexerIndex = getIndexOf(Indexer);
  if (IndexerIndex == -1)
    return false;

  CommandToBeSend = extractComand(0, IndexerIndex);
  // Serial.println(CommandToBeSend);
  if (CommandToBeSend == NA_Command)
    return false;

  DataToBeSend = extractData(IndexerIndex + 1);
  // Serial.println(DataToBeSend);
  if (DataToBeSend == -1)
    return false;

  return true;
}
//gets the index of a char in a string
int getIndexOf(char SearchedChar)
{
  uint8_t currentIndex = 0;
  while (SerialBuffer[currentIndex] != SearchedChar)
  {
    if (SerialBuffer[currentIndex] == EndChar)
      break;
    currentIndex++;
  }

  return SerialBuffer[currentIndex] == SearchedChar ? currentIndex : -1;
}
//extracts the Command part
Commands extractComand(int begin, int end)
{
  int SizeOfSubstring = (end - begin);
  char SubString[SizeOfSubstring];
  for (int i = begin; i < SizeOfSubstring; i++)
  {
    SubString[i] = SerialBuffer[i];
  }

  if (CompareStrings(SubString, "SET_A", SizeOfSubstring))
    return SET_A;
  else if (CompareStrings(SubString, "SET_B", SizeOfSubstring))
    return SET_B;
  else if (CompareStrings(SubString, "MIN", SizeOfSubstring))
    return MIN;
  else if (CompareStrings(SubString, "MAX", SizeOfSubstring))
    return MAX;
  else
    return NA_Command;
}
//comaparesthe strings
bool CompareStrings(char *String1, const char String2[], int SizeOfString1)
{
  uint8_t String2Lenght = strlen(String2);

  if (SizeOfString1 != String2Lenght)
    return false;

  for (int i = 0; i < SizeOfString1; i++)
  {
    if (String1[i] != String2[i])
      return false;
  }
  return true;
}
//Expracts the Data part
int extractData(uint8_t begin)
{
  int Data = 0;
  int endChar = getIndexOf(EndChar);

  while (SerialBuffer[begin] != EndChar)
  {
    if (((int)SerialBuffer[begin] - (int)'0') < 0 || ((int)SerialBuffer[begin] - (int)'0') > 9)
      return -1;

    Data += ((int)SerialBuffer[begin] - (int)'0') * powerOf(10, (endChar - begin) - 1);
    begin++;
  }
  return Data;
}
// custom Power Func
int powerOf(int base, int power)
{
  if (power == 0)
  {
    return 1;
  }
  else if (power == 1)
  {
    return base;
  }
  else
  {
    for (int i = 0; i < power - 1; i++)
    {
      base *= base;
    }
    return base;
  }
}

//--------------- I2C_COM --------------//

void I2C_COM_Sequence()
{
  switch (I2C_ComBus_State)
  {
  case SENDING:
    TransmitMsg();
    I2C_ComBus_State = RECEIVING;
    break;
  case RECEIVING:
    if (ReceiveMsg())
      I2C_ComBus_State = SUCCESS_CHECK;
    break;
  case SUCCESS_CHECK:
    if (CommandToBeSend == SET_A || CommandToBeSend == SET_B)
    {
      if (CheckupData == DataToBeSend)
        ProgramProceed();
    }
    else
    {
      ProgramProceed();
    }

    I2C_ComBus_State = SENDING;
    // Serial.println(ProgramState);
    break;
  }
}

void TransmitMsg()
{
  Wire.beginTransmission(DeviceAddress);

  Wire.write(RegisterAddresses[(int)CommandToBeSend]);
  Wire.write(DataToBeSend);
  Wire.write(EndChar);

  Wire.endTransmission();
}

bool ReceiveMsg()
{
  Wire.requestFrom(DeviceAddress, 2);
  while (Wire.available() > 0)
  {
    int input = Wire.read();
    //  Serial.print(input);
    if (input == RegisterAddresses[(int)CommandToBeSend])
    {
      // Serial.println(input);
      CheckupData = Wire.read();
      // Serial.println(CheckupData);
      return true;
    }
  }
  return false;
}

//---------- Serial Output -----------//

void printOutput()
{
  Serial.print("\n-> ");
  if (CommandToBeSend == SET_A || CommandToBeSend == SET_B)
  {
    Serial.print("Register set to: ");
  }
  else if (CommandToBeSend == MIN)
  {
    Serial.print("Min value is: ");
  }
  else
  {
    Serial.print("Max value is: ");
  }
  Serial.print(CheckupData);
  Serial.print("\n> ");
  ProgramProceed();
}

//-------------- IDLE ---------------//

void Reloading()
{
  static bool isDot = true;
  if (millis() - AnimationTime > 200)
  {
    if (AnimationCounter == 3)
    {
      isDot = !isDot;
      for (int i = 0; i < AnimationCounter; i++)
        Serial.print((char)0x08);
      AnimationCounter = 0;
    }
    else
    {
      if (isDot)
        Serial.print('.');
      else
        Serial.print((char)0x20);
      AnimationCounter++;
    }
    AnimationTime = millis();
  }
}