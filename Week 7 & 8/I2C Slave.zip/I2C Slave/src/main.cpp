#include <Arduino.h>
#include <Wire.h>
#define IAddress 42

#define MIN(a, b) ((a < b) ? a : b)
#define MAX(a, b) ((a > b) ? a : b)

const uint8_t EndChar = '#';
uint8_t LastcommandReceived;
uint8_t CheckData;

const int CommandsAdress[4] = {21, 22, 23, 24};

// FOR THE SLAVE

int RegisterA = 0;
int RegisterB = 0;

void receiveEvent(int HowMany);
void requestEvent();

void setup()
{
  // put your setup code here, to run once:

  Serial.begin(9600);

  Wire.begin(IAddress);
  Wire.onReceive(receiveEvent);
  Wire.onRequest(requestEvent);
}

void loop()
{
  // put your main code here, to run repeatedly:
}
void requestEvent()
{
  Wire.write(LastcommandReceived);
  Wire.write(CheckData);
}

void receiveEvent(int HowMany)
{
  while (Wire.available() > 0)
  {
    byte input = Wire.read();

    switch (input)
    {
    case 21:
      RegisterA = Wire.read();
      CheckData = RegisterA;
      LastcommandReceived = 21;
      // Serial.print(RegisterA);
      break;
    case 22:
      RegisterB = Wire.read();
      // Serial.print(RegisterB);
      LastcommandReceived = 22;
      CheckData = RegisterB;
      break;
    case 23:
      CheckData = MIN(RegisterA, RegisterB);
      LastcommandReceived = 23;
      break;
    case 24:
      CheckData = MAX(RegisterA, RegisterB);
      LastcommandReceived = 24;
      break;
    }
    //Serial.println(input);
  }
}